import os

# File to store student data
DATA_FILE = "students.txt"

# Function to load student data
def load_students():
    if not os.path.exists(DATA_FILE):
        return []
    with open(DATA_FILE, "r") as file:
        return [line.strip().split(",") for line in file.readlines()]

# Function to save student data
def save_students(students):
    with open(DATA_FILE, "w") as file:
        for student in students:
            file.write(",".join(student) + "\n")

# Function to add a new student
def add_student():
    student_id = input("Enter student ID: ")
    name = input("Enter student name: ")
    age = input("Enter student age: ")
    course = input("Enter student course: ")
    students.append([student_id, name, age, course])
    save_students(students)
    print("Student added successfully.")

# Function to display all students
def display_students():
    if not students:
        print("No students found.")
        return
    print(f"{'ID':<10}{'Name':<20}{'Age':<5}{'Course':<15}")
    print("-" * 50)
    for student in students:
        print(f"{student[0]:<10}{student[1]:<20}{student[2]:<5}{student[3]:<15}")

# Function to search for a student by ID
def search_student():
    search_id = input("Enter student ID to search: ")
    for student in students:
        if student[0] == search_id:
            print(f"Student found: {student}")
            return
    print("Student not found.")

# Function to update student details
def update_student():
    update_id = input("Enter student ID to update: ")
    for student in students:
        if student[0] == update_id:
            print(f"Current details: {student}")
            student[1] = input("Enter new name: ") or student[1]
            student[2] = input("Enter new age: ") or student[2]
            student[3] = input("Enter new course: ") or student[3]
            save_students(students)
            print("Student updated successfully.")
            return
    print("Student not found.")

# Function to delete a student
def delete_student():
    delete_id = input("Enter student ID to delete: ")
    for student in students:
        if student[0] == delete_id:
            students.remove(student)
            save_students(students)
            print("Student deleted successfully.")
            return
    print("Student not found.")

# Main program
students = load_students()

while True:
    print("\nStudent Management System")
    print("1. Add Student")
    print("2. Display Students")
    print("3. Search Student")
    print("4. Update Student")
    print("5. Delete Student")
    print("6. Exit")
    choice = input("Enter your choice: ")

    if choice == "1":
        add_student()
    elif choice == "2":
        display_students()
    elif choice == "3":
        search_student()
    elif choice == "4":
        update_student()
    elif choice == "5":
        delete_student()
    elif choice == "6":
        print("Exiting program.")
        break
    else:
        print("Invalid choice. Please try again.")
